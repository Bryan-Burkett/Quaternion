Team 1 Quaternions project for EECS 448 Spring 2014


Project Leader: Bryan Burkett
Project Analysis: Eric Chanthorabout
Programmers: Tim Clark   Aaron Cowdrey   Thomas Ford
Documentation: Dawson Conway   Austin Applegate
Billing: Jonathan Coup
Support: Justin Arnspiger   Qin Chen
Business Consultants: Evan Bissell   Miguel Angel Calderon Mejia


TestFile.rkt is empty except for requiring Quaternion.rkt and qreader.rkt. Use it to test our program.

Quaternion.rkt contains our quaternion calculator.
qreader.rkt contains the reader to allow interpretation of quaternions in standard notation.

Documentation.html is the documentation for our project.
styles contains all of the .css files for Documentation.html and must be in the same directory as Documentation.html

Enjoy!